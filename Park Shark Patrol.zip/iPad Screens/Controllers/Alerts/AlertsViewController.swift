//
//  AlertsViewController.swift
//  iPad Screens
//
//  Created by Gianna Rao on 11/1/24.
//

import UIKit


class AlertsViewController: UISplitViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
