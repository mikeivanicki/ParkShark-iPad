//
//  AlertsModel.swift
//  iPad Screens
//
//  Created by Gianna Rao on 11/5/24.
//

import Foundation

class AlertsModel{
   
    //test data
    var startDate = "11-5-2024"
    var endDate = "11-30-2024"
    var postedBy = "user1"
    var description = "task description"

   
}

